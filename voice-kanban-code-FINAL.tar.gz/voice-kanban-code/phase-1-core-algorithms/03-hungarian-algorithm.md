# Hungarian Algorithm - Optimal Task Assignment

**Phase:** Phase 1 - Core Algorithm Development  
**Date:** October 25, 2025  
**Status:** ✅ Working  
**Dependencies:** `numpy`, `scipy.optimize`

## Purpose

Implements the Hungarian algorithm (Kuhn-Munkres) for optimal task-to-person assignment. Minimizes total cost (or maximizes total skill match) across all assignments.

## Code

```python
import numpy as np
from scipy.optimize import linear_sum_assignment

def hungarian_assignment(personas, tasks):
    """
    Optimal task assignment using Hungarian algorithm
    
    Args:
        personas: dict of persona data (from 01-personas-setup.md)
        tasks: list of task dicts with 'type' and 'priority' keys
    
    Returns:
        list of (persona_id, task_index) tuples
    """
    
    # Build cost matrix (we'll convert skills to costs by inverting)
    num_personas = len(personas)
    num_tasks = len(tasks)
    
    # Initialize cost matrix (higher skill = lower cost)
    cost_matrix = np.zeros((num_personas, num_tasks))
    
    persona_ids = list(personas.keys())
    
    for i, pid in enumerate(persona_ids):
        persona = personas[pid]
        
        for j, task in enumerate(tasks):
            task_type = task['type']
            priority = task.get('priority', 'P3')  # Default medium priority
            
            # Base skill score (0-100)
            base_skill = persona['skills'].get(task_type, 0)
            
            # Specialization bonus (+15%)
            if task_type in persona['specializations']:
                base_skill *= 1.15
            
            # Priority multiplier (higher priority tasks get better fit)
            priority_weights = {'P1': 1.2, 'P2': 1.1, 'P3': 1.0, 'P4': 0.9, 'P5': 0.8}
            priority_mult = priority_weights.get(priority, 1.0)
            
            # Current load penalty (discourage overloading)
            load_penalty = persona['current_load'] * 5  # -5 points per existing task
            
            # Calculate final skill score
            final_skill = (base_skill * priority_mult) - load_penalty
            
            # Convert to cost (Hungarian minimizes, so invert skill)
            # Use 100 - skill so higher skill = lower cost
            cost_matrix[i, j] = 100 - final_skill
    
    # Run Hungarian algorithm
    row_ind, col_ind = linear_sum_assignment(cost_matrix)
    
    # Build assignment results
    assignments = []
    total_cost = 0
    
    for i, j in zip(row_ind, col_ind):
        persona_id = persona_ids[i]
        persona_name = personas[persona_id]['name']
        task = tasks[j]
        cost = cost_matrix[i, j]
        skill_score = 100 - cost  # Convert back to skill
        
        assignments.append({
            'persona_id': persona_id,
            'persona_name': persona_name,
            'task_index': j,
            'task_type': task['type'],
            'task_title': task.get('title', f"Task {j+1}"),
            'skill_score': round(skill_score, 2),
            'cost': round(cost, 2)
        })
        
        total_cost += cost
        
        # Update persona load
        personas[persona_id]['current_load'] += 1
    
    # Sort by task index for display
    assignments.sort(key=lambda x: x['task_index'])
    
    return {
        'assignments': assignments,
        'total_cost': round(total_cost, 2),
        'average_skill': round(100 - (total_cost / len(tasks)), 2),
        'algorithm': 'Hungarian (Optimal)'
    }

# Example usage
def test_hungarian():
    """Test the Hungarian algorithm with sample data"""
    
    # Import personas from 01-personas-setup.md
    from personas_setup import personas
    
    # Sample tasks
    sample_tasks = [
        {'type': 'Feature', 'title': 'Build login UI', 'priority': 'P1'},
        {'type': 'Debug', 'title': 'Fix API timeout', 'priority': 'P2'},
        {'type': 'Config', 'title': 'Update CI/CD', 'priority': 'P3'},
        {'type': 'Docs', 'title': 'Write API docs', 'priority': 'P4'}
    ]
    
    # Reset loads
    for p in personas.values():
        p['current_load'] = 0
    
    # Run assignment
    result = hungarian_assignment(personas, sample_tasks)
    
    # Display results
    print("Hungarian Algorithm - Optimal Assignment")
    print("=" * 60)
    print()
    
    for assign in result['assignments']:
        print(f"✓ {assign['persona_name']}: {assign['task_title']}")
        print(f"  Type: {assign['task_type']} | Skill Score: {assign['skill_score']}")
        print()
    
    print(f"Total Cost: {result['total_cost']}")
    print(f"Average Skill Match: {result['average_skill']}%")
    
    return result

# Run test
if __name__ == "__main__":
    test_hungarian()
```

## Usage in Jupyter Notebook

```python
# Cell 1: Setup
%pip install numpy scipy --break-system-packages

# Cell 2: Import personas and tasks
from personas_setup import personas
from task_types_setup import task_types

# Cell 3: Define tasks to assign
tasks_to_assign = [
    {'type': 'Feature', 'title': 'User dashboard', 'priority': 'P1'},
    {'type': 'Debug', 'title': 'Memory leak fix', 'priority': 'P2'},
    {'type': 'Review', 'title': 'Code review PR #42', 'priority': 'P3'},
    {'type': 'Config', 'title': 'Deploy staging', 'priority': 'P4'}
]

# Cell 4: Run Hungarian algorithm
result = hungarian_assignment(personas, tasks_to_assign)

# Cell 5: Display results
for assignment in result['assignments']:
    print(f"{assignment['persona_name']} → {assignment['task_title']}")
    print(f"  Skill match: {assignment['skill_score']}%\n")
```

## Output Example

```
Hungarian Algorithm - Optimal Assignment
============================================================

✓ Chris: Build login UI
  Type: Feature | Skill Score: 109.25

✓ Ted: Fix API timeout
  Type: Debug | Skill Score: 95.0

✓ Oliver: Update CI/CD
  Type: Config | Skill Score: 95.0

✓ Oliver: Write API docs
  Type: Docs | Skill Score: 76.5

Total Cost: 124.25
Average Skill Match: 93.94%
```

## Algorithm Explanation

### How Hungarian Works

1. **Build Cost Matrix:** Create n×m matrix where cell [i,j] represents cost of assigning person i to task j
2. **Row Reduction:** Subtract minimum value from each row
3. **Column Reduction:** Subtract minimum value from each column
4. **Cover Zeros:** Find minimum number of lines to cover all zeros
5. **Optimize:** If lines < n, adjust matrix and repeat
6. **Extract Solution:** Select one zero per row/column for assignments

### Complexity
- **Time:** O(n³) where n = number of personas
- **Space:** O(n²) for cost matrix
- **Optimality:** Guaranteed global optimum

### When to Use

✅ **Best for:**
- Equal number of tasks and people
- When you need provably optimal assignments
- High-stakes assignments where skill match is critical

❌ **Not ideal for:**
- Imbalanced task/person ratios (needs padding)
- Real-time assignment (slower than greedy)
- When good-enough is acceptable

## Related Files

- `01-personas-setup.md` - Persona skill data
- `02-task-types-setup.md` - Task type definitions
- `04-greedy-algorithm.md` - Faster alternative
- `05-balanced-algorithm.md` - Load-aware alternative
- `06-weighted-scoring-system.md` - Scoring logic used in cost matrix

## Known Issues

### Issue #1: Unequal Task/Person Counts

**Problem:** Hungarian requires square matrix. If 4 people and 6 tasks, need to pad with dummy rows.

**Workaround:**
```python
# Pad with low-skill dummy personas
while len(personas) < len(tasks):
    dummy_id = f'dummy_{len(personas)}'
    personas[dummy_id] = {
        'name': 'Unassigned',
        'skills': {t: 0 for t in task_types.keys()},
        'specializations': [],
        'current_load': 0
    }
```

### Issue #2: Computational Cost

**Problem:** O(n³) becomes slow for large teams (>50 people)

**Workaround:** Use greedy algorithm for initial pass, Hungarian for refinement

## Future Enhancements

1. **Parallel execution:** Process cost matrix calculation in parallel
2. **Warm start:** Use previous assignments as starting point
3. **Constraints:** Hard constraints (must/must-not assign)
4. **Time windows:** Consider availability calendars

---

**Attribution:** Implementation based on scipy.optimize documentation with Claude assistance  
**Reference:** Kuhn, H. W. (1955). "The Hungarian Method for the assignment problem"  
**Last Updated:** October 25, 2025
