# Task Types Setup - Six Kanban Categories

**Phase:** Phase 1 - Core Algorithm Development  
**Date:** October 2025  
**Status:** ✅ Working  
**Dependencies:** None (foundational data structure)

## Purpose

Defines the six task type categories used in Voice Kanban: Config, Feature, Debug, Docs, Review, and Refactor. Each type has associated metadata for visualization and priority weighting.

## Code

```python
# Voice Kanban - Task Type Definitions
# Six categories covering typical software development work

task_types = {
    'Config': {
        'name': 'Configuration',
        'description': 'Setup, deployment, environment config, CI/CD',
        'icon': '⚙️',
        'color': '#F59E0B',  # Amber
        'typical_weight': 30,
        'common_assignees': ['Oliver', 'Chris'],
        'examples': [
            'Update production environment variables',
            'Configure new CI/CD pipeline',
            'Set up development database',
            'Deploy staging environment'
        ]
    },
    
    'Feature': {
        'name': 'Feature Development',
        'description': 'New functionality, user stories, enhancements',
        'icon': '✨',
        'color': '#EC4899',  # Pink
        'typical_weight': 64,
        'common_assignees': ['Chris', 'Dana'],
        'examples': [
            'Implement user authentication',
            'Build dashboard analytics view',
            'Add export to CSV functionality',
            'Create notification system'
        ]
    },
    
    'Debug': {
        'name': 'Bug Fixes',
        'description': 'Troubleshooting, error fixes, hotfixes',
        'icon': '🐛',
        'color': '#EF4444',  # Red
        'typical_weight': 50,
        'common_assignees': ['Ted', 'Chris'],
        'examples': [
            'Fix login redirect loop',
            'Resolve memory leak in data processing',
            'Debug API timeout errors',
            'Patch security vulnerability'
        ]
    },
    
    'Docs': {
        'name': 'Documentation',
        'description': 'Technical docs, API references, user guides',
        'icon': '📝',
        'color': '#8B5CF6',  # Purple
        'typical_weight': 30,
        'common_assignees': ['Oliver', 'Dana'],
        'examples': [
            'Write API endpoint documentation',
            'Update user onboarding guide',
            'Create architecture diagram',
            'Document deployment process'
        ]
    },
    
    'Review': {
        'name': 'Code Review',
        'description': 'PR reviews, QA testing, security audits',
        'icon': '👁️',
        'color': '#10B981',  # Green
        'typical_weight': 35,
        'common_assignees': ['Ted', 'Dana'],
        'examples': [
            'Review Phase 2 pull request',
            'QA test new feature branch',
            'Security audit of authentication',
            'Performance review of database queries'
        ]
    },
    
    'Refactor': {
        'name': 'Code Refactoring',
        'description': 'Code cleanup, optimization, tech debt reduction',
        'icon': '🔧',
        'color': '#3B82F6',  # Blue
        'typical_weight': 40,
        'common_assignees': ['Chris', 'Ted'],
        'examples': [
            'Refactor legacy authentication module',
            'Optimize database query performance',
            'Extract reusable components',
            'Update deprecated dependencies'
        ]
    }
}

# Task type lookup helpers
def get_task_type_info(task_type):
    """Get complete information about a task type"""
    return task_types.get(task_type, None)

def get_all_task_types():
    """Return list of all valid task type keys"""
    return list(task_types.keys())

def get_typical_weight(task_type):
    """Get the typical complexity weight for a task type"""
    return task_types.get(task_type, {}).get('typical_weight', 50)

def get_task_type_color(task_type):
    """Get the hex color code for UI visualization"""
    return task_types.get(task_type, {}).get('color', '#6B7280')

# Display task types catalog
def print_task_catalog():
    """Pretty print all task types with details"""
    print("Voice Kanban Task Type Catalog")
    print("=" * 60)
    print()
    
    for task_id, info in task_types.items():
        print(f"{info['icon']} {task_id.upper()} - {info['name']}")
        print(f"   Description: {info['description']}")
        print(f"   Typical Weight: {info['typical_weight']}")
        print(f"   Usually Assigned To: {', '.join(info['common_assignees'])}")
        print(f"   Examples:")
        for example in info['examples'][:2]:  # Show first 2 examples
            print(f"      • {example}")
        print()

# Example usage
print_task_catalog()
```

## Usage

```python
# In HP AI Studio Jupyter notebook:
# Cell 1: Copy entire task_types dictionary

# Cell 2: Test task type access
feature_info = get_task_type_info('Feature')
print(f"Feature typical weight: {feature_info['typical_weight']}")

# Cell 3: Get all valid types for validation
valid_types = get_all_task_types()
print(f"Valid task types: {valid_types}")

# Cell 4: Color mapping for UI
for task_type in get_all_task_types():
    color = get_task_type_color(task_type)
    print(f"{task_type}: {color}")
```

## Output Example

```
Voice Kanban Task Type Catalog
============================================================

⚙️ CONFIG - Configuration
   Description: Setup, deployment, environment config, CI/CD
   Typical Weight: 30
   Usually Assigned To: Oliver, Chris
   Examples:
      • Update production environment variables
      • Configure new CI/CD pipeline

✨ FEATURE - Feature Development
   Description: New functionality, user stories, enhancements
   Typical Weight: 64
   Usually Assigned To: Chris, Dana
   Examples:
      • Implement user authentication
      • Build dashboard analytics view
```

## Design Decisions

### Six Core Types
- **Comprehensive coverage:** Captures 90%+ of development work
- **Mutually exclusive:** Clear boundaries between categories
- **Industry standard:** Aligns with Agile/Scrum terminology

### Weight Scale
- **30-64 range:** Config/Docs lighter, Features heavier
- **Fibonacci-inspired:** 30, 35, 40, 50, 64 for estimation
- **Adjustable:** Can be overridden per task instance

### Color Coding
- **Accessibility:** High contrast colors for visibility
- **Semantic meaning:** Red for bugs, green for review, blue for code
- **Hex format:** Direct CSS/HTML integration

## Task Type Priority Matrix

```
High Complexity, High Impact:
├── Feature (64)
└── Debug (50)

Medium Complexity:
├── Refactor (40)
└── Review (35)

Lower Complexity:
├── Config (30)
└── Docs (30)
```

## Voice Command Mapping

When users say:
- "Create **task**" → Feature
- "Fix **bug**" → Debug
- "Update **config**" → Config
- "Write **docs**" → Docs
- "Review **PR**" → Review
- "**Refactor** code" → Refactor

## Related Files

- `01-personas-setup.md` - Defines who gets assigned these tasks
- `06-weighted-scoring-system.md` - Uses task weights in calculations
- `10-keyword-matching-parser.md` - Maps voice commands to task types
- `08-gradio-interface.md` - Displays task types visually

## Known Issues

None - this is a static reference that works reliably.

## Future Enhancements

1. **Dynamic weights:** Learn from actual completion times
2. **Custom types:** Allow users to define additional categories
3. **Sub-types:** e.g., Feature → [UI, Backend, API]
4. **Complexity tiers:** Small/Medium/Large variants of each type

---

**Attribution:** Task type taxonomy developed with Claude Sonnet 4.5  
**Last Updated:** October 26, 2025
