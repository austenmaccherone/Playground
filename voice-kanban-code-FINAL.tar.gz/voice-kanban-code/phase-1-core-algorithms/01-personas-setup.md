# Personas Setup - Development Team Structure

**Phase:** Phase 1 - Core Algorithm Development  
**Date:** October 2025  
**Status:** ✅ Working  
**Dependencies:** None (foundational data structure)

## Purpose

Defines the four team member personas (Dana, Chris, Ted, Oliver) with their roles, base skill scores, and specialization preferences for the Voice Kanban task assignment system.

## Code

```python
# Voice Kanban - Persona Definitions
# Four team members with different skill profiles

personas = {
    'P1': {
        'name': 'Dana',
        'role': 'Designer',
        'skills': {
            'Config': 60,
            'Feature': 85,
            'Debug': 40,
            'Docs': 75,
            'Review': 80,
            'Refactor': 50
        },
        'specializations': ['Feature', 'Review', 'Docs'],
        'current_load': 0,  # Number of tasks currently assigned
        'icon': '🎨',
        'color': '#EC4899'  # Pink
    },
    
    'P2': {
        'name': 'Chris',
        'role': 'Coder',
        'skills': {
            'Config': 90,
            'Feature': 95,
            'Debug': 85,
            'Docs': 60,
            'Review': 70,
            'Refactor': 90
        },
        'specializations': ['Feature', 'Refactor', 'Config'],
        'current_load': 0,
        'icon': '💻',
        'color': '#3B82F6'  # Blue
    },
    
    'P3': {
        'name': 'Ted',
        'role': 'Tester',
        'skills': {
            'Config': 70,
            'Feature': 50,
            'Debug': 95,
            'Docs': 65,
            'Review': 90,
            'Refactor': 60
        },
        'specializations': ['Debug', 'Review', 'Config'],
        'current_load': 0,
        'icon': '🔍',
        'color': '#10B981'  # Green
    },
    
    'P4': {
        'name': 'Oliver',
        'role': 'Ops',
        'skills': {
            'Config': 95,
            'Feature': 60,
            'Debug': 80,
            'Docs': 85,
            'Review': 75,
            'Refactor': 70
        },
        'specializations': ['Config', 'Docs', 'Debug'],
        'current_load': 0,
        'icon': '⚙️',
        'color': '#F59E0B'  # Amber
    }
}

# Persona lookup helpers
def get_persona_by_name(name):
    """Retrieve persona by name (Dana, Chris, Ted, Oliver)"""
    for pid, persona in personas.items():
        if persona['name'].lower() == name.lower():
            return pid, persona
    return None, None

def get_persona_skill(persona_id, task_type):
    """Get a persona's skill score for a specific task type"""
    return personas[persona_id]['skills'].get(task_type, 0)

def has_specialization(persona_id, task_type):
    """Check if task type is in persona's specialization list"""
    return task_type in personas[persona_id]['specializations']

# Example usage
print("Development Team Roster:")
print("-" * 50)
for pid, p in personas.items():
    print(f"{p['icon']} {p['name']} ({p['role']})")
    print(f"   Specializes in: {', '.join(p['specializations'])}")
    print(f"   Top skill: {max(p['skills'], key=p['skills'].get)} "
          f"({max(p['skills'].values())})")
    print()
```

## Usage

```python
# In HP AI Studio Jupyter notebook:
# Cell 1: Copy entire personas dictionary

# Cell 2: Test persona access
dana_id, dana = get_persona_by_name('Dana')
print(f"Dana's Feature skill: {dana['skills']['Feature']}")

# Cell 3: Check specializations
is_specialist = has_specialization('P1', 'Feature')
print(f"Is Dana specialized in Feature? {is_specialist}")
```

## Output Example

```
Development Team Roster:
--------------------------------------------------
🎨 Dana (Designer)
   Specializes in: Feature, Review, Docs
   Top skill: Feature (85)

💻 Chris (Coder)
   Specializes in: Feature, Refactor, Config
   Top skill: Feature (95)

🔍 Ted (Tester)
   Specializes in: Debug, Review, Config
   Top skill: Debug (95)

⚙️ Oliver (Ops)
   Specializes in: Config, Docs, Debug
   Top skill: Config (95)
```

## Design Decisions

### Skill Score Range
- **0-100 scale:** Makes percentage calculations intuitive
- **Distribution:** Each persona has 1-2 strong skills (85-95), 2-3 moderate (60-80), 1-2 weak (40-60)
- **Rationale:** Reflects real T-shaped team members (deep in specialty, broad in others)

### Specialization Bonus
- **15% boost:** Applied when task type matches specialization
- **Max 3 specializations:** Prevents over-generalization
- **Purpose:** Incentivizes task routing to domain experts

### Current Load Tracking
- **Initialized to 0:** Updated during assignment
- **Used in:** Load balancing algorithm to prevent burnout
- **Reset:** Can be cleared for new sprint planning

## Related Files

- `02-task-types-setup.md` - Defines the task categories
- `06-weighted-scoring-system.md` - Uses persona skills in calculations
- `03-hungarian-algorithm.md` - Assignment algorithm implementation
- `08-gradio-interface.md` - Visual display of personas

## Known Issues

None - this is a static data structure that works reliably.

## Future Enhancements

1. **Dynamic skill updating:** Learn from completed tasks
2. **Availability calendar:** Block out vacation/meetings
3. **Cross-training tracking:** Record when someone works outside specialty
4. **Burnout detection:** Flag when load exceeds threshold

---

**Attribution:** Persona structure developed with Claude Sonnet 4.5 assistance  
**Last Updated:** October 26, 2025
