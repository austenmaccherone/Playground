# Voice Kanban - Complete Code Documentation

**Project:** Voice Kanban - AI-Driven Task Orchestration System  
**Course:** AI-560: Applied AI Design & Development Lab  
**Student:** DF-R302-02  
**Timeline:** September 9 - November 13, 2025

## 📁 Folder Organization

This documentation contains all code developed throughout the Voice Kanban capstone project, organized by development phase and component type.

### Directory Structure

```
voice-kanban-code/
├── 00-README.md (this file)
├── phase-1-core-algorithms/
│   ├── 01-personas-setup.md
│   ├── 02-task-types-setup.md
│   ├── 03-hungarian-algorithm.md
│   ├── 04-greedy-algorithm.md
│   ├── 05-balanced-algorithm.md
│   └── 06-weighted-scoring-system.md
├── phase-1-interface/
│   ├── 07-flask-app-setup.md
│   ├── 08-gradio-interface.md
│   ├── 09-material-design-styling.md
│   └── 10-keyword-matching-parser.md
├── phase-1-5-api-integration/
│   ├── 11-github-authentication.md
│   ├── 12-github-api-test.md
│   ├── 13-create-issue.md
│   ├── 14-list-issues.md
│   ├── 15-update-issue-status.md
│   ├── 16-add-labels.md
│   └── 17-api-practice-guide-full.md
├── phase-2-voice-integration/
│   ├── 18-whisper-setup.md
│   ├── 19-whisper-mic-input.md
│   ├── 20-audio-processing.md
│   └── 21-voice-command-parser.md
├── mcp-integration/
│   ├── 22-mcp-json-formatter.md
│   ├── 23-mcp-server-connection.md
│   └── 24-gitlab-kanban-integration.md
├── errors-and-debugging/
│   ├── 25-npm-errors-mcp-clone.md
│   ├── 26-audio-library-errors.md
│   ├── 27-authentication-failures.md
│   └── 28-integration-troubleshooting.md
├── utilities/
│   ├── 29-data-structures.md
│   ├── 30-helper-functions.md
│   └── 31-configuration-setup.md
└── complete-system/
    ├── 32-phase-1-full-implementation.md
    └── 33-jupyter-notebook-8-cell-template.md
```

## 🎯 Phase Overview

### Phase 1: Core Algorithm Development (September-October)
- **Personas:** Dana (Designer), Chris (Coder), Ted (Tester), Oliver (Ops)
- **Task Types:** Config, Feature, Debug, Docs, Review, Refactor
- **Algorithms:** Hungarian, Greedy, Balanced assignment methods
- **Scoring:** Weighted system combining skills, specialization, load, priority

### Phase 1.5: API Integration Practice (October)
- **Focus:** GitHub API mastery through 8-step tutorial
- **Components:** Authentication, CRUD operations, JSON payloads
- **Learning:** Token formatting, rate limiting, error handling

### Phase 2: Voice Integration (October-November)
- **Tool:** Whisper Large V3 for speech-to-text
- **Commands:** 13 categories (create, move, delete, status, queries)
- **Architecture:** Voice → Text → Intent → Action

### MCP Integration (October-November)
- **Goal:** Connect AI reasoning to actual Kanban boards
- **Platforms:** GitHub Projects, GitLab Kanban, Trello, Jira
- **Protocol:** Model Context Protocol for standardized communication

## 🔧 Technology Stack

- **Environment:** HP AI Studio (Ubuntu 24, NVIDIA GPU)
- **Languages:** Python 3.x
- **Frameworks:** Flask, Gradio
- **AI Models:** Whisper Large V3, Claude API
- **APIs:** GitHub REST API, GitLab API
- **Notebooks:** Jupyter (8-cell template methodology)

## 📝 Code Documentation Format

Each markdown file follows this structure:

```markdown
# [Component Name]

**Phase:** [Phase number and name]
**Date:** [Development date]
**Status:** [Working / Error / Deprecated]
**Dependencies:** [Required libraries/files]

## Purpose
[What this code does]

## Code
```python
[Actual code]
```

## Usage
[How to run/implement]

## Known Issues
[Errors encountered]

## Related Files
[Connected components]
```

## ⚠️ Important Notes

1. **All code is copy-paste ready** for HP AI Studio environment
2. **Error documentation included** - failures have equal academic value
3. **8-cell template** structure maintained throughout
4. **Attribution logs** available for all Claude-assisted development
5. **Sequential execution** - run cells in order, don't skip

## 🚀 Quick Start Guide

1. Start with `phase-1-core-algorithms/` for foundation
2. Move to `phase-1-interface/` for UI implementation
3. Practice with `phase-1-5-api-integration/` before production
4. Attempt `phase-2-voice-integration/` for advanced features
5. Reference `errors-and-debugging/` when troubleshooting

## 📊 Development Statistics

- **Total Code Files:** 33+ documented components
- **Lines of Code:** ~2,000+ across all phases
- **Claude Interactions:** 50+ documented sessions
- **Error Iterations:** 15+ debugging cycles documented
- **API Calls Tested:** 8 GitHub operations validated

## 🎓 Academic Compliance

- All code attributed to sources (Claude, professor examples, official docs)
- Conversation logs exported for portfolio appendix
- Failures documented with root cause analysis
- Ethical framework integrated from Day 1

---

**Last Updated:** November 13, 2025  
**Portfolio Submission:** [Add your blog URL here]
